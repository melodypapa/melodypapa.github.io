Document Title:                 Meta Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 059
Document Status:                Final
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       4.3.1
Date:                           2017-12-08
