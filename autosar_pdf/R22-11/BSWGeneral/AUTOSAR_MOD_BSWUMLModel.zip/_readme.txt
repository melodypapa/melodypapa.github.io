Document Title:                 Basic Software UML Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 052
Document Status:                published
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       R22-11
Date:                           2022-11-24
